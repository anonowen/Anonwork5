/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Anon
 */
@Entity
@Table(name = "products")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Products.findAll", query = "SELECT p FROM Products p"),
    @NamedQuery(name = "Products.findByProductID", query = "SELECT p FROM Products p WHERE p.productsPK.productID = :productID"),
    @NamedQuery(name = "Products.findByCategoryID", query = "SELECT p FROM Products p WHERE p.productsPK.categoryID = :categoryID"),
    @NamedQuery(name = "Products.findByProductName", query = "SELECT p FROM Products p WHERE p.productName = :productName"),
    @NamedQuery(name = "Products.findByProductDes", query = "SELECT p FROM Products p WHERE p.productDes = :productDes"),
    @NamedQuery(name = "Products.findByPrice", query = "SELECT p FROM Products p WHERE p.price = :price"),
    @NamedQuery(name = "Products.findByQuantity", query = "SELECT p FROM Products p WHERE p.quantity = :quantity"),
    @NamedQuery(name = "Products.findByCartID", query = "SELECT p FROM Products p WHERE p.productsPK.cartID = :cartID"),
    @NamedQuery(name = "Products.findByUserID", query = "SELECT p FROM Products p WHERE p.productsPK.userID = :userID")})
public class Products implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ProductsPK productsPK;
    @Size(max = 40)
    @Column(name = "productName")
    private String productName;
    @Size(max = 40)
    @Column(name = "productDes")
    private String productDes;
    @Size(max = 40)
    @Column(name = "price")
    private String price;
    @Size(max = 40)
    @Column(name = "quantity")
    private String quantity;
    @JoinTable(name = "userorder", joinColumns = {
        @JoinColumn(name = "productID", referencedColumnName = "productID"),
        @JoinColumn(name = "categoryID", referencedColumnName = "categoryID"),
        @JoinColumn(name = "cartID", referencedColumnName = "cartID"),
        @JoinColumn(name = "userID", referencedColumnName = "userID")}, inverseJoinColumns = {
        @JoinColumn(name = "userID", referencedColumnName = "userID")})
    @ManyToMany
    private Collection<Users> usersCollection;
    @JoinColumns({
        @JoinColumn(name = "cartID", referencedColumnName = "cartID", insertable = false, updatable = false),
        @JoinColumn(name = "userID", referencedColumnName = "userID", insertable = false, updatable = false)})
    @ManyToOne(optional = false)
    private Cart cart;
    @JoinColumn(name = "categoryID", referencedColumnName = "categoryID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Categories categories;

    public Products() {
    }

    public Products(ProductsPK productsPK) {
        this.productsPK = productsPK;
    }

    public Products(String productID, String categoryID, String cartID, String userID) {
        this.productsPK = new ProductsPK(productID, categoryID, cartID, userID);
    }

    public ProductsPK getProductsPK() {
        return productsPK;
    }

    public void setProductsPK(ProductsPK productsPK) {
        this.productsPK = productsPK;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductDes() {
        return productDes;
    }

    public void setProductDes(String productDes) {
        this.productDes = productDes;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    @XmlTransient
    public Collection<Users> getUsersCollection() {
        return usersCollection;
    }

    public void setUsersCollection(Collection<Users> usersCollection) {
        this.usersCollection = usersCollection;
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }

    public Categories getCategories() {
        return categories;
    }

    public void setCategories(Categories categories) {
        this.categories = categories;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (productsPK != null ? productsPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Products)) {
            return false;
        }
        Products other = (Products) object;
        if ((this.productsPK == null && other.productsPK != null) || (this.productsPK != null && !this.productsPK.equals(other.productsPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "db.Products[ productsPK=" + productsPK + " ]";
    }
    
}
